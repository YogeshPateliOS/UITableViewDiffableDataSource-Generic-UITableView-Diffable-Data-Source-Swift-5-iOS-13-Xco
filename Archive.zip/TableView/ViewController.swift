//
//  ViewController.swift
//  TableView
//
//  Created by Yogesh Patel on 4/9/20.
//  Copyright © 2020 Yogesh Patel. All rights reserved.
//

import UIKit

struct UserModel: Hashable{
    var name = ""
}

typealias UserDataSource = UITableViewDiffableDataSource<TblSection, UserModel>
typealias UserSnapshot = NSDiffableDataSourceSnapshot<TblSection, UserModel>

class ViewController: UIViewController {

    var arrData = [UserModel]()
    @IBOutlet weak var tblView: UITableView!
    let searchController = UISearchController(searchResultsController: nil)
    var datasource: UserDataSource!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureDatasource()
        arrData = getAllData()
        createSnapshot(users: arrData)
        addSearchbar()
    }
    
    func configureDatasource(){
        datasource = UserDataSource(tableView: tblView, cellProvider: { (tableView, indexPath, user) -> UITableViewCell? in
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = user.name
            return cell
        })
    }
    
    func addUser(name: String){
        arrData.append(UserModel(name: name))
        createSnapshot(users: arrData)
    }
    
    func createSnapshot(users: [UserModel]){
        var snapshot = UserSnapshot()
        snapshot.appendSections([.first])
        snapshot.appendItems(users)
        datasource.apply(snapshot, animatingDifferences: true)
    }
    
    func getAllData() -> [UserModel]{
        return [
            UserModel(name: "Person 1"),
            UserModel(name: "Person 2"),
            UserModel(name: "Person 3"),
            UserModel(name: "Person 4"),
            UserModel(name: "Person 5"),
            UserModel(name: "Person 6")
        ]
    }
    
    func addSearchbar(){
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Search Users"
        self.navigationItem.searchController = searchController
        self.definesPresentationContext = true
    }
    
    @IBAction func btnAddClick(_ sender: Any) {
        let alert = UIAlertController(title: "", message: "Add User Detail", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Okay", style: .default) { (okTarget) in
            if let txtName = alert.textFields?.first?.text {
                self.addUser(name: txtName)
            }
        }
        alert.addTextField { (txtUser) in
            txtUser.placeholder = "Enter username"
        }
        alert.addAction(ok)
        self.present(alert, animated: true)
    }
}

enum TblSection{
    case first
}


extension ViewController: UISearchResultsUpdating {

    func updateSearchResults(for searchController: UISearchController) {
        let searchText = searchController.searchBar.text
        if searchText == ""{
            arrData = getAllData()
        }else{
            arrData = getAllData().filter{ $0.name.contains(searchText!) }
        }
        createSnapshot(users: arrData)
    }
}

extension ViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user = datasource.itemIdentifier(for: indexPath)
        print(user)
    }
}
